// Import the necessary modules here
import { blogs } from "../models/blog.model"; // Import the blogs array from the blog.model module

// Render Blogs
export const renderBlogs = (req, res) => {
  res.render("blogs", { blogs });
};

// Render Blog Form
export const renderBlogForm = (req, res) => {
  res.render("addBlogForm");
};

// Add New Blog
export const addBlog = (req, res) => {
  const { title, description, img } = req.body;
  const newBlog = { title, description, img };
  blogs.push(newBlog);
  res.redirect("/");
};
